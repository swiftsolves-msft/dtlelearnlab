import { Component, Injector } from '@angular/core';
import { LabCreationGenerated } from './lab-creation-generated.component';

@Component({
  selector: 'lab-creation',
  templateUrl: './lab-creation.component.html'
})
export class LabCreationComponent extends LabCreationGenerated {
  constructor(injector: Injector) {
    super(injector);
  }
}
