import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule, ActivatedRoute } from '@angular/router';

import { PageTitleComponent } from './app.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { LabCreationComponent } from './lab-creation/lab-creation.component';


export const routes: Routes = [
  {
    path: 'sign-up',
    children: [
      {
        path: '',
        component: SignUpComponent
      },
      {
        path: '',
        component: PageTitleComponent,
        outlet: 'title',
        data: {
          title: 'SignUp'
        }
      }
    ]
  },
  {
    path: 'sign-up',
    component: SignUpComponent,
    outlet: 'popup',
    data: {
      title: 'SignUp'
    }
  },
  {
    path: 'lab-creation',
    children: [
      {
        path: '',
        component: LabCreationComponent
      },
      {
        path: '',
        component: PageTitleComponent,
        outlet: 'title',
        data: {
          title: 'Lab Creation'
        }
      }
    ]
  },
  {
    path: 'lab-creation',
    component: LabCreationComponent,
    outlet: 'popup',
    data: {
      title: 'Lab Creation'
    }
  },
  { path: '', redirectTo: '/sign-up', pathMatch: 'full' }
];

export const AppRoutes: ModuleWithProviders = RouterModule.forRoot(routes);
