import { Component, Injector } from '@angular/core';
import { SignUpGenerated } from './sign-up-generated.component';

@Component({
  selector: 'sign-up',
  templateUrl: './sign-up.component.html'
})
export class SignUpComponent extends SignUpGenerated {
  constructor(injector: Injector) {
    super(injector);
  }
}
